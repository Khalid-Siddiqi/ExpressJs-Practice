blogs = [
    {
        title: "How to write your first Alphabets",
        content: "this is A,B & C",
        slug: "abc"
    },
    {
        title: "How to write your last Alphabets",
        content: "this is X,Y & Z",
        slug: "xyz"
    },
    {
        title: "How to write your last numbers",
        content: "this is 7,8 & 9",
        slug: "789"
    },
    {
        title: "How to write your first numbers",
        content: "this is 1,2 & 3",
        slug: "123"
    }

]
module.exports = blogs;