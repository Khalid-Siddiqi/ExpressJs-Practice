const express = require('express')
const { engine } = require('express-handlebars');

const app = express();
const path= require('path')
const port = 3000

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views');


app.use(express.static(path.join(__dirname,"static")))
app.use('/', require(path.join(__dirname, 'routes/blog.js')))

app.listen(port, () => {
  console.log(`BLog app listening on port ${port}`)
})