const express = require('express')
const app = express()
const path= require('path')
const port = 3000

app.use(express.static(path.join(__dirname,"public")))
app.get('/', (req, res) => {
  res.send('Hello World!')
})
app.get('/contact/:name', (req, res) => {
    res.send('Hi There '+ req.params.name)
  })
app.get('/about', (req, res) => {
    //res.send('about menpm install -g nodemon')
    //res.sendFile(path.join(__dirname,'index.html'))
    res.json({"harry": 34, "aqib": 56, "death": true, "gender": "male"})
  })
app.get('/hello', (req, res) => {
    //res.send('about menpm install -g nodemon')
    res.sendFile(path.join(__dirname,'index.html'))
    //res.json({"harry": 34, "aqib": 56, "death": true, "gender": "male"})
  })

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})